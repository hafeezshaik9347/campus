from django.contrib import admin

# Register your models here.
from college.models import College

# Register your models here.
class Clgadmin(admin.ModelAdmin):
    list_display=['user','id','name','dept']

admin.site.register(College,Clgadmin)