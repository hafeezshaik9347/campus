from django.db import models

# Create your models here.
class College(models.Model):
    user=models.CharField(max_length=50,unique=True)
    id=models.CharField(max_length=50,primary_key=True)
    name=models.CharField(max_length=50)
    dept=models.CharField(max_length=10)

    def __str__(self):
        return self.name
