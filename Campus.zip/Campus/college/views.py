from django.shortcuts import redirect, render
from django.contrib.auth import views as auth_views
from django.contrib.auth.decorators import login_required
from student.forms import CustomLoginForm
from college.models import College
from student.models import Application
from company.models import company

class CustomLoginView(auth_views.LoginView):
    form_class = CustomLoginForm
    template_name = 'registration/login.html'  # Path to your login template

@login_required
def clgProfile(request):
    user=request.user
    c=College.objects.get(user=user)
    dept=c.dept
    cnt=Application.objects.filter(dept=dept).values('Roll_Number').distinct().count()
    pa=Application.objects.filter(dept=dept,Status__iexact='pending').count()
    p_cnt= Application.objects.filter(dept=dept,Status__iexact='placed').values('Roll_Number').distinct().count()
    s=Application.objects.filter(dept=dept,Status__iexact='Shortlisted').values('Roll_Number').distinct().count()
    r=Application.objects.filter(dept=dept,Status__iexact='Rejected').values('Roll_Number').distinct().count()
    dict={'c':c,'cnt':cnt,'p_cnt':p_cnt,'s':s,'r':r,'pa':pa}
    return render(request,'college/clg_profile.html',dict)


def viewApplications(request):
    user=request.user
    c=College.objects.get(user=user)
    dept=c.dept
    data=Application.objects.filter(dept=dept)
    dict={'data':data}
    return render(request,'college/view_applications.html',dict)

@login_required
def PlacementCell(request):
    user=request.user
    c=College.objects.get(user=user)
    data=Application.objects.all()
    cnt=Application.objects.values('Roll_Number').distinct().count()
    pa=Application.objects.filter(Status__iexact='pending').count()
    p_cnt= Application.objects.filter(Status__iexact='placed').values('Roll_Number').distinct().count()
    s=Application.objects.filter(Status__iexact='Shortlisted').values('Roll_Number').distinct().count()
    r=Application.objects.filter(Status__iexact='Rejected').values('Roll_Number').distinct().count()
    dict={'data':data,'c':c,'cnt':cnt,'p_cnt':p_cnt,'s':s,'r':r,'pa':pa}
    return render(request,'college/po.html',dict)


from college.forms import CompanyModelForm
def Addco(request):
    form=CompanyModelForm()
    if request.method == 'POST':
        form=CompanyModelForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect('view_company')
    return render(request,'college/add_company.html',{'form':form})

def viewCompanies(request):
    data=company.objects.all()
    return render(request,'college/view_companies.html',{'data':data})

def DeleteCompany(request,id):
    com=company.objects.get(co_id=id)
    com.delete()
    return redirect('view_company')



