from django import forms
from company.models import company

class CompanyModelForm(forms.ModelForm):
    class Meta:
        model=company
        fields=['co_id','co_name']
