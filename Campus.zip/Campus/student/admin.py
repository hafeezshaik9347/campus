from django.contrib import admin
from student.models import Student,Application

# Register your models here.
class Studentadmin(admin.ModelAdmin):
    list_display=['user','roll','name','email','phone','gender','dept','CGPA','profile_pic']

class Applicationadmin(admin.ModelAdmin):
    list_display=['Roll_Number','Full_Name','Company_Name','CGPA','Skills','Status']

# Register your models here.
admin.site.register(Student,Studentadmin)
admin.site.register(Application,Applicationadmin)