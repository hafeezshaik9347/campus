from django.shortcuts import redirect, render
from django.contrib.auth import views as auth_views
from student.forms import CustomLoginForm,ApplicationForm, StudentModelForm
from django.contrib.auth.decorators import login_required

from student.models import Student,Application

# Create your views here.
def homePage(request):
    return render(request,'index.html')

from django.contrib.auth import logout
def Userlogout(request):
    logout(request)
    return redirect('home')

class CustomLoginView(auth_views.LoginView):
    form_class = CustomLoginForm
    template_name = 'registration/login.html'  # Path to your login template


@login_required
def StudentProfile(request):
    user=request.user
    s=Student.objects.get(user=user);
    dict={'s':s,'user':user}
    return render(request,'student/stu_profile.html',dict)


@login_required
def ApplyCompany(request):
    if request.method == 'POST':
        form = ApplicationForm(request.POST)
        if form.is_valid():
            application = form.save(commit=False)
            application.student = Student.objects.get(user=request.user)
            application.save()
            return redirect('dashboard')
    else:
        form = ApplicationForm()
    return render(request, 'student/apply_company.html', {'form': form})

@login_required
def Dashboard(request):
    student = Student.objects.get(user=request.user)
    applications = Application.objects.filter(Roll_Number=student.roll)
    return render(request, 'student/stu_dashboard.html', {'applications': applications})

@login_required
def updateStudent(request,id):
    s=Student.objects.get(id=id)
    form=StudentModelForm(instance=s)
    dict={'form':form}
    if request.method == 'POST':
        obj=StudentModelForm(data=request.POST, files=request.FILES, instance=s)
        if obj.is_valid():
            obj.save()
        return redirect('stu_profile')  # Redirect to the student profile view
    return render(request, 'student/stu_update.html', dict)

'''
@login_required
def updateStudent(request):
    user=request.user
    s=Student.objects.get(user=user)
    id=s.id
    s=Student.objects.get(id=id)
    form=StudentModelForm(instance=s)
    dict={'form':form}
    if request.method=='POST':
        obj=StudentModelForm(request.POST,request.FILES,instance=s)
        if obj.is_valid:
            obj.save()
        return StudentProfile(request)
    return render(request,'student/stu_update.html',dict)
'''

"""
@login_required
def updateStudent(request,id):
    s=Student.objects.get(id=id)
    form=StudentModelForm(instance=s)
    dict={'form':form}
    if request.method=='POST':
        obj=StudentModelForm(request.POST,instance=s)
        if obj.is_valid:
            obj.save()
        return StudentProfile(request)
    return render(request,'student/stu-update.html',dict)

'''
from django.contrib.auth.forms import UserCreationForm
def Register(request):
    form = UserCreationForm()
    success=False
    if request.method=='POST':
        form=UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
        return homePage(request)
    dict={'form':form,'success':success}
    return render(request,'student/register.html',dict)

from django.contrib.auth.forms import UserCreationForm
def Register(request):
    form = UserCreationForm()
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            # Create the Student profile
            Student.objects.create(user=user, roll=None, name=None, email=user.email, phone=None, dept=None, gender=None)
            return redirect('home')
    return render(request, 'student/register.html', {'form': form})
'''


"""