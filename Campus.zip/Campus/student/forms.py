from django import forms
from django.contrib.auth.forms import AuthenticationForm

from student.models import Student,Application


class CustomLoginForm(AuthenticationForm):
    username = forms.CharField(
        widget=forms.TextInput(attrs={'placeholder': 'Username', 'class': 'form-control'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': 'Password', 'class': 'form-control'})
    )

class StudentModelForm(forms.ModelForm):
    class Meta:
        model=Student
        fields=['CGPA','profile_pic']

class ApplicationForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = ['Roll_Number','Full_Name','dept','CGPA','Company_Name','Skills']
