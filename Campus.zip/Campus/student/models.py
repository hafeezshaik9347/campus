from django.db import models
from company.models import company

# Create your models here.

class Student(models.Model):
    user=models.CharField(max_length=50,unique=True)
    roll=models.CharField(max_length=15,unique=True)
    name=models.CharField(max_length=50)
    email=models.EmailField(unique=True)
    phone=models.CharField(max_length=15,unique=True)
    gender=models.CharField(max_length=6)
    dept=models.CharField(max_length=10)
    CGPA=models.FloatField(max_length=3,default=0.0)
    profile_pic=models.ImageField(default='df_pic.png',blank=True)

    def __str__(self):
        return self.roll

class Application(models.Model):
    Roll_Number = models.CharField(max_length=15)
    Full_Name=models.CharField(max_length=50)
    dept=models.CharField(max_length=10)
    CGPA=models.FloatField(max_length=3,default=0.0)
    Company_Name = models.ForeignKey(company, on_delete=models.CASCADE)
    Skills=models.CharField(max_length=100)
    Status = models.CharField(max_length=20, default='Pending')

    def __str__(self):
        return f'{self.student.roll} - {self.company_name.co_name}'
