from django.contrib import admin

# Register your models here.
from company.models import company

# Register your models here.
class coadmin(admin.ModelAdmin):
    list_display=['co_id','co_name']

admin.site.register(company,coadmin)