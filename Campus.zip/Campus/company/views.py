from django.shortcuts import get_object_or_404, redirect, render
from django.contrib.auth import views as auth_views
from student.forms import CustomLoginForm,ApplicationForm, StudentModelForm
from django.contrib.auth.decorators import login_required

from student.models import Application
from company.models import company

@login_required
def companyProfile(request):
    user=request.user
    c=company.objects.get(co_name=user)
    name=c.co_id
    a=Application.objects.filter(Company_Name_id=name)
    dict={'c':c,'a':a}
    return render(request,'company/co_profile.html',dict)


def shortlist(request,id,name):
    app=get_object_or_404(Application,Roll_Number=id,Company_Name__co_id=name)
    app.Status='Shortlisted'
    app.save()
    return redirect('co_profile')

def reject(request,id,name):
    app=get_object_or_404(Application,Roll_Number=id,Company_Name__co_id=name)
    app.Status='Rejected'
    app.save()
    return redirect('co_profile')

def shortlist_all(request,name):
    app=Application.objects.filter(Company_Name__co_id=name)
    for i in app:
        i.Status='Shortlisted'
        i.save()
    return redirect('co_profile')