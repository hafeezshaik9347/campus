"""
URL configuration for Campus project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from student import views
from django.conf.urls import include

from student.views import CustomLoginView,StudentProfile,Userlogout,Dashboard, ApplyCompany,updateStudent

from college.views import clgProfile,viewApplications,Addco,PlacementCell,viewCompanies,DeleteCompany

from company.views import companyProfile,shortlist,reject,shortlist_all

from django.contrib.auth import views as auth_views

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.homePage,name='home'),

    path('stu_profile/',StudentProfile,name='stu_profile'),

    path('clg_profile/',clgProfile,name='clg_profile'),

    path('co_profile/',companyProfile,name='co_profile'),
    path('shortlist/<str:id>/<str:name>',shortlist),
    path('reject/<str:id>/<str:name>',reject),
    path('shortlist_all/<str:name>',shortlist_all),

    path('userlogout/',Userlogout),

    path('addco/',Addco),
    path('po/',PlacementCell,name='placement_cell'),
    path('view_companies/',viewCompanies,name='view_company'),
    path('del_company/<str:id>/',DeleteCompany),

    path('apply/',ApplyCompany), 

    path('view_applications/',viewApplications),

    path('dashboard/',Dashboard,name='dashboard'),

    path('profile_update/<int:id>/',updateStudent),

    path('accounts/logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('accounts/password_change/', auth_views.PasswordChangeView.as_view(template_name='registration/password_change_form.html'), name='password_change'),
    path('accounts/password_change/done/', auth_views.PasswordChangeDoneView.as_view(template_name='registration/password_change_done.html'), name='password_change_done'),
   
    path('accounts/login/', CustomLoginView.as_view(), name='login'),
    path('accounts/', include('django.contrib.auth.urls')),
]

urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)


'''
path('apply/',ApplyCompany),
    path('profile_update/',views.updateStudent),
    path('dashboard',Dashboard),
'''